// To parse this JSON data, do
//
//     final pokedex = pokedexFromJson(jsonString);

import 'dart:convert';

Pokedex pokedexFromJson(String str) => Pokedex.fromJson(json.decode(str));

String pokedexToJson(Pokedex data) => json.encode(data.toJson());

class Pokedex {
    Pokedex({
        required this.the1050,
        required this.the1595,
        required this.the1658,
        required this.humidity,
        required this.movement,
        required this.temperature,
       required  this.users,
        required this.aciklama,
    });

    The1050 the1050;
    The1595 the1595;
    The1595 the1658;
    double humidity;
    bool movement;
    double temperature;
    Users users;
    String aciklama;

    factory Pokedex.fromJson(Map<String, dynamic> json) => Pokedex(
        the1050: The1050.fromJson(json["1050"]),
        the1595: The1595.fromJson(json["1595"]),
        the1658: The1595.fromJson(json["1658"]),
        humidity: json["Humidity"].toDouble(),
        movement: json["Movement"],
        temperature: json["Temperature"].toDouble(),
        users: Users.fromJson(json["Users"]),
        aciklama: json["aciklama"],
    );

    Map<String, dynamic> toJson() => {
        "1050": the1050.toJson(),
        "1595": the1595.toJson(),
        "1658": the1658.toJson(),
        "Humidity": humidity,
        "Movement": movement,
        "Temperature": temperature,
        "Users": users.toJson(),
        "aciklama": aciklama,
    };
}




class The1050 {
    The1050({
        required this.connection,
        required this.humidity,
        required this.location,
        required this.movement,
        required this.temperature,
    });

    String connection;
    double humidity;
    String location;
    bool movement;
    double temperature;

    factory The1050.fromJson(Map<String, dynamic> json) => The1050(
        connection: json["Connection"],
        humidity: json["Humidity"].toDouble(),
        location: json["Location"],
        movement: json["Movement"],
        temperature: json["Temperature"].toDouble(),
    );

    Map<String, dynamic> toJson() => {
        "Connection": connection,
        "Humidity": humidity,
        "Location": location,
        "Movement": movement,
        "Temperature": temperature,
    };
}

class The1595 {
    The1595({
        required this.connection,
        required this.humidity,
        required this.movement,
        required this.name,
        required this.position,
        required this.temperature,
        required this.blood,
    });

    String connection;
    double humidity;
    bool movement;
    String name;
    String position;
    double temperature;
    String blood;

    factory The1595.fromJson(Map<String, dynamic> json) => The1595(
        connection: json["Connection"],
        humidity: json["Humidity"].toDouble(),
        movement: json["Movement"],
        name: json["Name"],
        position: json["Position"],
        temperature: json["Temperature"].toDouble(),
        blood: json["Blood"] == null ? null : json["Blood"],
    );

    Map<String, dynamic> toJson() => {
        "Connection": connection,
        "Humidity": humidity,
        "Movement": movement,
        "Name": name,
        "Position": position,
        "Temperature": temperature,
        "Blood": blood == null ? null : blood,
    };
}

class Users {
    Users({
        required this.msBotuZxtZo3OWlLb4E,
        required this.msBp7JBzcF2HpSuMvIb,
        required this.msC2C3Mw3A8MYmzpuR,
        required this.msC2JtWrucK98AwImIt,
        required this.msC6Vc3QAyR42THxeiq,
        required this.msC6MgOxDjOAvRwPh0Q,
    });

    MsB msBotuZxtZo3OWlLb4E;
    MsB msBp7JBzcF2HpSuMvIb;
    MsC msC2C3Mw3A8MYmzpuR;
    MsC msC2JtWrucK98AwImIt;
    MsC msC6Vc3QAyR42THxeiq;
    MsC msC6MgOxDjOAvRwPh0Q;

    factory Users.fromJson(Map<String, dynamic> json) => Users(
        msBotuZxtZo3OWlLb4E: MsB.fromJson(json["-MsBotuZxtZO3oWLLb4e"]),
        msBp7JBzcF2HpSuMvIb: MsB.fromJson(json["-MsBp7JBzcF2HPSuMVIb"]),
        msC2C3Mw3A8MYmzpuR: MsC.fromJson(json["-MsC2c3mw3A8M_YmzpuR"]),
        msC2JtWrucK98AwImIt: MsC.fromJson(json["-MsC2jtWrucK98AWImIt"]),
        msC6Vc3QAyR42THxeiq: MsC.fromJson(json["-MsC6VC3qAyR42THxeiq"]),
        msC6MgOxDjOAvRwPh0Q: MsC.fromJson(json["-MsC6mgOXDjOAvRwPh0q"]),
    );

    Map<String, dynamic> toJson() => {
        "-MsBotuZxtZO3oWLLb4e": msBotuZxtZo3OWlLb4E.toJson(),
        "-MsBp7JBzcF2HPSuMVIb": msBp7JBzcF2HpSuMvIb.toJson(),
        "-MsC2c3mw3A8M_YmzpuR": msC2C3Mw3A8MYmzpuR.toJson(),
        "-MsC2jtWrucK98AWImIt": msC2JtWrucK98AwImIt.toJson(),
        "-MsC6VC3qAyR42THxeiq": msC6Vc3QAyR42THxeiq.toJson(),
        "-MsC6mgOXDjOAvRwPh0q": msC6MgOxDjOAvRwPh0Q.toJson(),
    };
}

class MsB {
    MsB({
        required this.blood,
        required this.connection,
        required this.disease,
        required this.humidity,
        required this.movement,
        required this.position,
        required this.temperature,
    });

    String blood;
    String connection;
    String disease;
    String humidity;
    String movement;
    String position;
    double temperature;

    factory MsB.fromJson(Map<String, dynamic> json) => MsB(
        blood: json["Blood"],
        connection: json["Connection"],
        disease: json["Disease"],
        humidity: json["Humidity"],
        movement: json["Movement"],
        position: json["Position"] == null ? null : json["Position"],
        temperature: json["Temperature"].toDouble(),
    );

    Map<String, dynamic> toJson() => {
        "Blood": blood,
        "Connection": connection,
        "Disease": disease,
        "Humidity": humidity,
        "Movement": movement,
        "Position": position == null ? null : position,
        "Temperature": temperature,
    };
}

class MsC {
    MsC({
        required this.connection,
        required this.humidity,
        required this.movement,
        required this.temperature,
    });

    String connection;
    String humidity;
    String movement;
    double temperature;

    factory MsC.fromJson(Map<String, dynamic> json) => MsC(
        connection: json["Connection"],
        humidity: json["Humidity"],
        movement: json["Movement"],
        temperature: json["Temperature"].toDouble(),
    );

    Map<String, dynamic> toJson() => {
        "Connection": connection,
        "Humidity": humidity,
        "Movement": movement,
        "Temperature": temperature,
    };
}
